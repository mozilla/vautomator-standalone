// +build windows

package libgobuster

func resetTerminal() string {
	return "\r\r"
}
